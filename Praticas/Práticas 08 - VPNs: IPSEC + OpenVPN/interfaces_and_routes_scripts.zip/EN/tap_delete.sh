#!/bin/bash
# script to delete virtual TAP interface

# load functions and variable from runCMD.cfg (must be on the same dir)
. runCMD.cfg

if [ $# -ne 1 ];then
  echo ""
  echo -e "Requires 1 argument: \t ${YELLOW}$0 «interface_name»${NONE}"
  echo -e "example:\t\t ${YELLOW}sudo $0 pc1${NONE}"
  echo ""
  exit
fi

TAP=$1

echoY "Disabling interface: $TAP ..."
runCmdOrExit "ip l s dev $TAP down" && echoY "[ok]"

echoY "Deleting interface: $TAP ..."
runCmdOrExit "ip l d dev $TAP" && echoY "[ok]"



