#!/bin/bash
# script to create static route

# load functions and variable from runCMD.cfg (must be on the same dir)
. runCMD.cfg

if [ $# -ne 2 ];then
  echo ""
  echo -e "Requires 2 arguments: \t ${YELLOW}$0 «network_slash_mask» «interface_name»${NONE}"
  echo -e "example:\t\t ${YELLOW}sudo $0 172.168.10.0/24 pc1${NONE}"
  echo ""
  exit
fi

REDE=$1
TAP=$2

echoY "Creating static route for network $REDE through interface $TAP ..."
runCmdOrExit "ip route add $REDE dev $TAP" && echoY "[ok]"

echoY "Check routing configurations ..."
runCmdOrExit "ip r" && echo "" && echoY "[ok]"

