#!/bin/bash
# script to create a TAP virtual interface

# load functions and variable from runCMD.cfg (must be on the same dir)
. runCMD.cfg

if [ $# -ne 2 ];then
  echo ""
  echo -e "Requires 2 arguments: \t ${YELLOW}$0 «interface_name» «ip_slash_mask»${NONE}"
  echo -e "example:\t\t ${YELLOW}sudo $0 pc1 10.10.10.10/24${NONE}"
  echo ""
  exit
fi

TAP=$1
IP=$2

echoY "Creating TAP interface: $TAP ..."
runCmdOrExit "ip tuntap add dev $TAP mode tap" && echoY "[ok]"

echoY "Enabeling interface: $TAP ..."
runCmdOrExit "ip l s dev $TAP up" && echoY "[ok]"

echoY "Setup $TAP with $IP ..."
runCmdOrExit "ip a a $IP dev $TAP" && echoY "[ok]"

echoY "Checking configurations of $TAP ..."
runCmdOrExit "ip a s dev $TAP" && echo "" && echoY "[ok]"
